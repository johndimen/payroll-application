# College-PayrollApplication
A simple C# payroll system created for a college assignment
